
namespace cpp FIXComp
namespace d FIXComp
namespace dart FIXComp
namespace java FIXComp
namespace php FIXComp
namespace perl FIXComp
namespace haxe FIXComp
namespace netcore FIXComp

enum TradeRequestState
{
  INIT,
  APPLIED,
  COMPLETED,
  CANCELLED
}

struct TradeRequest
{
  1:  required  i32     HedgeAccountId,               ///< Account making request
  2:  required  i32     SecurityId,                   ///< SecurityId (Future) for this request
  3:  required  bool    IsBuy,                        ///< True if this is a purchase
  4:  required  i32     Quantity,                     ///< Number of contracts required
  5:  required  bool    IsRebalance,                  ///< True if this is a rebalance trade
  6:  required  string  TraderId,                     ///< Trader identifier  16 chars
  7:  required  i32     ClearingCpartyId,             ///< Clearing counterparty identifier
  8:  required  string  RequestTime,                  ///< Time the trade was requested
  9:  optional  string  ResolvedTime,                 ///< Time the request was resolved
  10: optional  i32    ExecutingCPartyId,            ///< Executityn counterparty identifier
  11: optional  i32     RollFromSecurityId,           ///< SecurityId of the rolled from future
  12: required  string  GID,                          ///< Return the global identifier for the trade to which this request was assigned
  13: required  string  PrevGID,                      ///< The previos GID for this request before cancel/replace
  14: optional  TradeRequestState TradeRequestStateId ///< Current state of the request
}

typedef list<TradeRequest>  TradeRequestList;

/**
 * Structs can also be exceptions, if they are nasty.
 */
exception InvalidOperation
{
  1: i32 whatOp,
  2: string why
}

/**
 * These are the messages that EMSX FIX supports
 * Will be used for BB compliance test
**/
service EMSX_FIX
{
  TradeRequest SubmitNewSingleOrder(1: TradeRequest trade) throws (1: InvalidOperation ex);
  TradeRequest SubmitFuturesSpreadOrder(1: TradeRequest trade) throws (1: InvalidOperation ex);
  TradeRequest SubmitNewBatchOrder(1: TradeRequest trade) throws (1: InvalidOperation ex);
  i32 CancelOrder(1: string GID) throws (1: InvalidOperation ex);
  TradeRequest CancelReplaceOrder(1: string GID) throws (1: InvalidOperation ex);

  i32         ping();
  oneway void quit();
}

// TraderDashboard needed functions
service TD_EMSX 
{
    TradeRequestList  RequestTrades(1: TradeRequestList tradeReqList) throws (1: InvalidOperation ex);
    TradeRequestList  TradeRequestAfterDateTime(1: string asOfTime) throws (1: InvalidOperation ex);

    i32         ping();
    oneway void quit();
}

// These go from the server  (Comp) to the Client
service FIX_RESPONSE
{
  void ExecutionReport(1: TradeRequest trade) throws (1: InvalidOperation ex);
  void OrderCancelReject(1: TradeRequest trade) throws (1: InvalidOperation ex);
  void DontKnowTrade(1: string GID) throws (1: InvalidOperation ex);
}
