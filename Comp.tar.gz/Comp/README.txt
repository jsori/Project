Prograns created:
TestClient - send rpc request to compliance server
           - uses Apache thrift to rpc Comp
	   
Comp       - the compliance server.
             1. takes rpc request containing orders
	     2. formats to FIX 4.2 orders for Bloomberg (BB)
	     3. waits for status messages from BB
	     4. Once an order is done send delivery instructions

            - uses quickfix
	    
TestServer - test basic communication with Comp. Acts as BB

quickfix
http://www.quickfixengine.org/

got the FIX42.xml from  fix8-1.4.0/schema the FIX8 directories.
other schemas are there.

the thrift code generation. puts the code in directory gen-cpp

thrift --gen cpp FIXComp.thrift
