//
//

#include "Config.h"

const char* DEFAULT_HOST = "ec2-54-213-204-106.us-west-2.compute.amazonaws.com";

Config::Config() : _desc("Allowed Options")
{
    _desc.add_options()
            ("help,h", "produce help message")
            ("rpcHost,r", po::value<std::string>()->default_value("localhost"), "rpc host")
            ("rpcPort,p", po::value<int>()->default_value(DEFAULT_RPC_PORT), "rpc port number")
            ("testRpcPort,t", po::value<int>()->default_value(TEST_RPC_PORT), "test rpc port number")
            ("tstSvrXML,x", po::value<std::string>()->default_value("tstSvr.xml"), "test server config xml")
      /*
            ("test,x", po::value<int>()->default_value(0), "test number")
            ("testLoops,n", po::value<int>()->default_value(100), "rnumber of times to run test")
            ("threads,t", po::value<int>()->default_value(1), "server port number")
            ("remote,r", po::value<std::string>()->default_value(DEFAULT_HOST), "Remote server host")
            ("logfile,f", po::value<std::string>()->default_value("MT_V2_Acceptor"), "Log file prefix")
            ("logsize,s", po::value<int>()->default_value(1), "Log file size in megs - default 1")
            ("logmaxstore,m", po::value<int>()->default_value(24), "Max log files stored, size in megs - default 24")
            ("loglevel,l", po::value<int>()->default_value(2), "Log Level - 1 = trace, 2 = debug, 3 = info, 4 = waring, 5 = error, 6 = fatal - default 2")
            ("client,c", "Run client test")
            ("logconsole,t", "Run console log")
      */
            ;

}
bool Config::parse(int argc, char* argv[])
{
    bool    result  = true;
    po::store(po::parse_command_line(argc, argv, _desc), _vm);
    po::notify(_vm);

    if (_vm.count("help"))
        result = false;


    return result;
}

// clients use this
std::string Config::rpcHost() const
{
    return _vm["rpcHost"].as<std::string>();
}

int Config::rpcPort() const
{
    int     result = DEFAULT_RPC_PORT;
    if (_vm.count("rpcPort"))
    {
        result = _vm["rpcPort"].as<int>();
    }
    return result;
}
int Config::testRpcPort() const
{
    int     result = TEST_RPC_PORT;
    if (_vm.count("testRpcPort"))
    {
        result = _vm["testRpcPort"].as<int>();
    }
    return result;
}

// the test FIX server xml config file
std::string Config::testServerXML() const
{
    return _vm["tstSvrXML"].as<std::string>();
}

/*
int Config::test() const
{
    return _vm["test"].as<int>();
}
int Config::testLoops() const
{
    return _vm["testLoops"].as<int>();
}
int Config::port() const
{
    int     result = DEFAULT_PORT;
    if (_vm.count("port"))
    {
        result = _vm["port"].as<int>();
    }
    return result;
}
int Config::numthreads() const
{
    int dflt = 1;
    if (_vm.count("threads"))
    {
        int nthread = _vm["threads"].as<int>();
        if (nthread > 0 && nthread < 11)
        {
            dflt = nthread;
        }
    }
    return dflt;
}
int Config::logFileSize() const
{
    int dflt = 1;
    if (_vm.count("logsize"))
    {
        int logsize =_vm["logsize"].as<int>();
        if (logsize > 0 && logsize < 10)
        {
            dflt = logsize;
        }
    }
    return dflt;
}
int Config::logFileMaxStore() const
{
    int dflt = 1;
    if (_vm.count("logmaxstore"))
    {
        int logsize = _vm["logmaxstore"].as<int>();
        if (logsize > 10 && logsize < 100)
        {
            dflt = logsize;
        }
    }
    return dflt;
}
int Config::loglevel() const
{
    int dflt = 2;
    if (_vm.count("logmaxstore"))
    {
        int leglevel = _vm["loglevel"].as<int>();
        if (leglevel > 0 && leglevel < 7)
        {
            dflt = leglevel;
        }
    }
    return dflt;
}
std::string Config::remote() const
{
    return _vm["remote"].as<std::string>();
}
std::string Config::logprefix() const
{
    return _vm["logfile"].as<std::string>();
}
bool Config::runClient() const
{
    bool dflt = false;
    if (_vm.count("runclient"))
        dflt = true;
    return dflt;
}
bool Config::runConsoleLog() const
{
    bool dflt = false;
    if (_vm.count("logconsole"))
        dflt = true;
    return dflt;
}
*/
