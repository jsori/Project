/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

#include <iostream>

#include <thrift/protocol/TBinaryProtocol.h>
#include <thrift/transport/TSocket.h>
#include <thrift/transport/TTransportUtils.h>
#include <thrift/stdcxx.h>

#include "gen-cpp/EMSX_FIX.h"
#include "gen-cpp/TD_EMSX.h"

#include "Config.h"
#include <boost/log/trivial.hpp>

using namespace std;
using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;

void singleRequest( FIXComp::EMSX_FIXClient &client);

void requestList( FIXComp::TD_EMSXClient &client);

int main(int argc, char **argv)
{
    Config  config;
    bool    go = true;
    int     result = 0;
    int     tNum = 0;
    
    if (!config.parse(argc,argv))
    {
        BOOST_LOG_TRIVIAL(debug) << config;
        result = -1;
    }
    else
    {
        stdcxx::shared_ptr<TTransport> socket(new TSocket(config.rpcHost(), config.rpcPort() ));
        stdcxx::shared_ptr<TTransport> transport(new TBufferedTransport(socket));
        stdcxx::shared_ptr<TProtocol> protocol(new TBinaryProtocol(transport));
	FIXComp::EMSX_FIXClient client(protocol);

	stdcxx::shared_ptr<TTransport> socket2(new TSocket(config.rpcHost(), config.testRpcPort() ));
        stdcxx::shared_ptr<TTransport> transport2(new TBufferedTransport(socket2));
        stdcxx::shared_ptr<TProtocol> protocol2(new TBinaryProtocol(transport2));
	FIXComp::TD_EMSXClient client2(protocol2);
	std::cout << config << std::endl;
	
        try
        {
            transport->open();
            transport2->open();
	    while(go == true)
	    {
	        std::cout << "1.   single TradeRequest" << std::endl
	                  << "2.   TradeRequest list" << std::endl
		          << "3.   10 TradeRequests sent then 1 second rest start again: 10 times" << std::endl
		          << "4.   quit rpc - Closes rpc: this test stops: fix connection still up " << std::endl
	                  << "5.   stop compliance server: sends quit and breaks rpc connection." << std::endl
		          << "test: ";
	        std::cin >> tNum;
	      
	       switch(tNum)
	       {
	         case 1:
		   singleRequest( client);
		   break;
	         case 2:
		   requestList( client2);
		   break;
	         case 3:
	           std::cout << "not implemented" << std::endl;
		   break;
	         case 4:
                   transport->close();
                   transport2->close();
		   go = false;
		   break;
	         case 5:
		   client.quit();
                   transport->close();
		   client2.quit();
                   transport2->close();
		   go = false;
  		   break;
	         default:
		   break;
	       }
	    }

            transport2->close();
        } catch (TException& tx)
	  {
	    BOOST_LOG_TRIVIAL(error) << "ERROR: " << tx.what();
	  }
    }
}
void singleRequest( FIXComp::EMSX_FIXClient &client)
{
  FIXComp::TradeRequest req;
  FIXComp::TradeRequest reqRet;

  req.GID = "000";
  std::cout << "singleRequest(): req GID: " << req.GID  << " reqRet GID: " << reqRet.GID << std::endl;
  
  client.SubmitNewSingleOrder(reqRet, req);

  std::cout << "singleRequest(): req GID: " << req.GID  << " reqRet GID: " << reqRet.GID << std::endl;
}

void requestList( FIXComp::TD_EMSXClient &client)
{
  int i = 0;
  FIXComp::TradeRequest req1;
  FIXComp::TradeRequest req2;
  FIXComp::TradeRequest req3;

  FIXComp::TradeRequestList requestList;
  FIXComp::TradeRequestList replyList;

  // load list
  requestList.push_back(req1);
  requestList.push_back(req2);
  requestList.push_back(req3);

  client.RequestTrades(replyList, requestList);
  for(i = 0; i < replyList.size(); i++)
    std::cout << "reply: " << i << " GID: " << replyList[i].GID << std::endl;
  
  std::cout <<  "number of orders submitted: " << requestList.size()
            << " should be 3 replies: " << replyList.size() << std::endl; 
}
