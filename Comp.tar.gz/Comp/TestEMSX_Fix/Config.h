//
//
#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <iostream>
#include <boost/program_options.hpp>

namespace po = boost::program_options;

//const int DEFAULT_RPC_PORT = 3170;
#define DEFAULT_RPC_PORT 3170
#define TEST_RPC_PORT 3171

class Config
{
public:
    Config();
    bool            parse(int argc, char* argv[]);
    std::string     rpcHost() const;
    int             rpcPort() const;
    int             testRpcPort() const;
    std::string     testServerXML() const;
    /*
    int             test() const;
    int             testLoops() const;
    int             testNumber() const;
    int             numthreads() const;
    int             logFileSize() const;
    int             logFileMaxStore() const;
    int             loglevel() const;
    std::string     remote() const;
    std::string     logprefix() const;
    bool            runClient() const;
    bool            runConsoleLog() const;
    */
    friend std::ostream& operator<<(std::ostream& o, const Config& cfg)
    {
        return o << cfg._desc << std::endl;
    }
private:
    po::options_description     _desc;
    po::variables_map           _vm;

};

#endif //_CONFIG_H_
