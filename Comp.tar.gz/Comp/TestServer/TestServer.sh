#!/bin/sh
../cmake-debug/TestServer ../cfg/TestServer.cfg
