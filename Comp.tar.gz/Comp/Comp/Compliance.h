#ifndef _COMPLIANCE_H_
#define _COMPLIANCE_H_

#include "Config.h"
#include <boost/log/trivial.hpp>

#include "quickfix/FileStore.h"
#include "quickfix/SocketInitiator.h"
#ifdef HAVE_SSL
#include "quickfix/ThreadedSSLSocketInitiator.h"
#include "quickfix/SSLSocketInitiator.h"
#endif
#include "quickfix/SessionSettings.h"
#include "quickfix/Log.h"
#include "thrift/server/TThreadedServer.h"

#include "FIXUtils.h"
#include "gen-cpp/FIXComp_types.h"
#include "EMSX_FIX_server.h"
class Compliance
{
 public:
  Compliance();
  virtual ~Compliance(); //shut down the servers

  void qFixInitiator(FIX::Initiator *initiator);
  void qFixUtils(FIXUtils *f);
  void addSvc( ::apache::thrift::server::TThreadedServer *svc);
  void addSvc2( ::apache::thrift::server::TThreadedServer *svc);
  void run(int instance);
  void stop(std::string &from); // stops all rpc svcs 
  FIXUtils &qFixUtils();
 private:

  /// NEED A mutex

  FIX::Initiator  *_qFix;
  FIXUtils        *_qFixUtils;
    
  ::apache::thrift::server::TThreadedServer* _svc;
  ::apache::thrift::server::TThreadedServer* _svc2;
};


#endif // _COMPLIANCE_H_
