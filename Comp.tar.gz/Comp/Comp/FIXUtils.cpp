#ifdef _MSC_VER
#pragma warning( disable : 4503 4355 4786 )
#else
//#include "config.h"
#endif

#include "FIXUtils.h"
#include "quickfix/Session.h"
#include <iostream>
#include <ctime>

static FIX::SessionID _sessionID;
static int _clOrdId = 1;

void FIXUtils::onLogon( const FIX::SessionID& sessionID )
{
  // mutex acquire
  boost::lock_guard<boost::mutex> lock{_replyMutex};
  // there should be only 1 session
  _sessionID = sessionID;
  BOOST_LOG_TRIVIAL(debug) << "Logon - "
			   << "SenderCompID: " << _sessionID.getSenderCompID()
                           << " TargetCompID: " << _sessionID.getTargetCompID();
}

void FIXUtils::onLogout( const FIX::SessionID& sessionID )
{
  // mutex acquire
  boost::lock_guard<boost::mutex> lock{_replyMutex};
  
  BOOST_LOG_TRIVIAL(debug) << "Logout - " << sessionID;
}

void FIXUtils::fromApp( const FIX::Message& message, const FIX::SessionID& sessionID )
throw( FIX::FieldNotFound, FIX::IncorrectDataFormat, FIX::IncorrectTagValue, FIX::UnsupportedMessageType )
{
  boost::lock_guard<boost::mutex> lock{_replyMutex};
  
  BOOST_LOG_TRIVIAL(debug) << "FIXUtils::fromApp(): _replyMutex: threadID:  "
			   << boost::this_thread::get_id();
  BOOST_LOG_TRIVIAL(debug) << "FIXUtils::fromApp(): " << message;

  crack( message, sessionID );
}

void FIXUtils::toApp( FIX::Message& message, const FIX::SessionID& sessionID )
throw( FIX::DoNotSend )
{
  boost::lock_guard<boost::mutex> lock{_replyMutex};
  try
  {
    BOOST_LOG_TRIVIAL(debug) << "FIXUtils::toApp(): _replyMutex: threadID:  "
			     << boost::this_thread::get_id();
    BOOST_LOG_TRIVIAL(debug) << "FIXUtils::toApp(): message: " << message;
    FIX::PossDupFlag possDupFlag;
    message.getHeader().getField( possDupFlag );
    if ( possDupFlag ) throw FIX::DoNotSend();
  }
  catch ( FIX::FieldNotFound& ) {}

}

void FIXUtils::onMessage( const FIX42::ExecutionReport& er, const FIX::SessionID& sessionID)
{
    boost::lock_guard<boost::mutex> lock{_replyMutex};
    FIX::ClOrdID    clordid;
    FIX::OrdStatus  ordStatus;
    FIX::LeavesQty  leavesQty;
    FIX::CumQty     cumQty;
    FIX::AvgPx      avgPx;

    er.getField(clordid);
    er.getField(ordStatus);
    er.getField(leavesQty);
    er.getField(cumQty);
    er.getField(avgPx);
    
    {
           boost::lock_guard<boost::mutex> lock{_dbMutex};

    BOOST_LOG_TRIVIAL(debug) << "FIXUtils::onMessage(ExecutionReport): _replyMutex: threadID:  "
			   << boost::this_thread::get_id();
    }
}
void FIXUtils::onMessage( const FIX42::OrderCancelReject& ocr, const FIX::SessionID& sessionId)
{
    boost::lock_guard<boost::mutex> lock{_replyMutex};

    FIX::ClOrdID clordid; // order that the cancel was rejected (i think) 
    ocr.getField(clordid);

    FIX::OrdStatus ordStatus;
    ocr.getField(ordStatus);
    
    {
        boost::lock_guard<boost::mutex> lock{_dbMutex};

        BOOST_LOG_TRIVIAL(debug) << "FIXUtils::onMessage(OrderCancelReject): _replyMutex: threadID:  "
			   << boost::this_thread::get_id();
    }
}

FIX42::NewOrderSingle FIXUtils::newOrderSingle(FIXComp::TradeRequest &request)
{
  FIX::OrdType ordType;
  int buySell = -1;
  if(request.IsBuy == true)
    buySell = 1;
  else
    buySell = 2;

  request.GID = getClOrdId(request.TraderId);  // init the GID for return
  FIX42::NewOrderSingle newOrderSingle(request.GID,           // how created
				       FIX::HandlInst( '1' ), // broker instructions
				                              // 1 = Automated execution order, private, no Broker intervention
                                                              // 2 = Automated execution order, public, Broker intervention OK
                                                              // 3 = Manual order, best execution

				       FIX::Symbol("IBM" ),// where from
				       FIX::Side(FIX::Side_BUY),
				       FIX::TransactTime(), // UTC , GMT
				       FIX::OrdType(FIX::OrdType_MARKET));     // where from: 1 MARKET, 2 LIMIT, 3 STOP etc.. 

  newOrderSingle.set( FIX::OrderQty(request.Quantity) );
/*
 FIX42::NewOrderSingle::NoPartyIDs group;
  group.set(FIX::PartyID("123"));
  group.set(FIX::PartyIDSource("BAD"));
  group.set(FIX::PartyRole("???"));

  newOrderSingle.addGroup(group);
*/
  /*
  <group name="NoPartyIDS" required="N">
      <field name="PartyID" required="Y"/>
      <field name="PartyIDSource" required="Y"/>
      <field name="PartyRole" required="Y"/>
    </group>
  
PartyID
  PartyIDSource
  OrderAttributeType
  */
  // newOrderSingle.set( FIX::TimeInForce( FIX::TimeInForce_DAY));
  
  // newOrderSingle.set( FIX::Price(101.11));

  newOrderSingle.getHeader().setField(FIX::SenderCompID(_sessionID.getSenderCompID()));
  newOrderSingle.getHeader().setField(FIX::TargetCompID(_sessionID.getTargetCompID()));

  FIX::Session::sendToTarget(newOrderSingle ); // exception thrown ?

  return newOrderSingle;
}

/*
FIX::Side FIXUtils::querySide()
{
  char value;
  BOOST_LOG_TRIVIAL(debug)
  << "1) Buy" << std::endl
  << "2) Sell" << std::endl
  << "3) Sell Short" << std::endl
  << "4) Sell Short Exempt" << std::endl
  << "5) Cross" << std::endl
  << "6) Cross Short" << std::endl
  << "7) Cross Short Exempt" << std::endl
  << "Side: ";

  std::cin >> value;
  switch ( value )
  {
    case '1': return FIX::Side( FIX::Side_BUY );
    case '2': return FIX::Side( FIX::Side_SELL );
    case '3': return FIX::Side( FIX::Side_SELL_SHORT );
    case '4': return FIX::Side( FIX::Side_SELL_SHORT_EXEMPT );
    case '5': return FIX::Side( FIX::Side_CROSS );
    case '6': return FIX::Side( FIX::Side_CROSS_SHORT );
    case '7': return FIX::Side( 'A' );
    default: throw std::exception();
  }
}

FIX::OrdType FIXUtils::queryOrdType()
{
  char value;
  BOOST_LOG_TRIVIAL(debug)
  << "1) Market" << std::endl
  << "2) Limit" << std::endl
  << "3) Stop" << std::endl
  << "4) Stop Limit" << std::endl
  << "OrdType: ";

  std::cin >> value;
  switch ( value )
  {
    case '1': return FIX::OrdType( FIX::OrdType_MARKET );
    case '2': return FIX::OrdType( FIX::OrdType_LIMIT );
    case '3': return FIX::OrdType( FIX::OrdType_STOP );
    case '4': return FIX::OrdType( FIX::OrdType_STOP_LIMIT );
    default: throw std::exception();
  }
}
FIX::Price FIXUtils::queryPrice()
{
  double value;
  BOOST_LOG_TRIVIAL(debug) << "Price: ";
  std::cin >> value;
  return FIX::Price( value );
}

FIX::StopPx FIXUtils::queryStopPx()
{
  double value;
  BOOST_LOG_TRIVIAL(debug) << "StopPx: ";
  std::cin >> value;
  return FIX::StopPx( value );
}

FIX::TimeInForce FIXUtils::queryTimeInForce()
{
  char value;
  BOOST_LOG_TRIVIAL(debug)
  << "1) Day" << std::endl
  << "2) IOC" << std::endl
  << "3) OPG" << std::endl
  << "4) GTC" << std::endl
  << "5) GTX" << std::endl
  << "TimeInForce: ";

  std::cin >> value;
  switch ( value )
  {
    case '1': return FIX::TimeInForce( FIX::TimeInForce_DAY );
    case '2': return FIX::TimeInForce( FIX::TimeInForce_IMMEDIATE_OR_CANCEL );
    case '3': return FIX::TimeInForce( FIX::TimeInForce_AT_THE_OPENING );
    case '4': return FIX::TimeInForce( FIX::TimeInForce_GOOD_TILL_CANCEL );
    case '5': return FIX::TimeInForce( FIX::TimeInForce_GOOD_TILL_CROSSING );
    default: throw std::exception();
  }
}
*/

void FIXUtils::processRequest(FIXComp::TradeRequest& _return, const FIXComp::TradeRequest& request)
{
  boost::lock_guard<boost::mutex> lock{_reqMutex};
  _return = request;
  {
    // store to the db
     boost::lock_guard<boost::mutex> lock{_dbMutex};
  }
  newOrderSingle(_return); // format to FIX and send
}

void FIXUtils::processFuturesSpreadOrder(FIXComp::TradeRequest& _return, const FIXComp::TradeRequest& request)
{
  boost::lock_guard<boost::mutex> lock{_reqMutex};
  _return = request;
  {
    // store to the db
     boost::lock_guard<boost::mutex> lock{_dbMutex};
  }
 }

void FIXUtils::processBatchOrder(FIXComp::TradeRequest& _return, const FIXComp::TradeRequest& request)
{
  boost::lock_guard<boost::mutex> lock{_reqMutex};
  _return = request;
  {
    // store to the db
     boost::lock_guard<boost::mutex> lock{_dbMutex};
  }
}

void FIXUtils::processCancelOrder(const std::string& GID)
{
  boost::lock_guard<boost::mutex> lock{_reqMutex};
  {
    {
        // read from the db
        boost::lock_guard<boost::mutex> lock{_dbMutex};

        // read order from db based on ClOrdId
	
        // FIX42::OrderCancelRequest orderCancelRequest( // original ClOrdId (the order to be cancelled,
	                                                 // the client ClOrdId of the new (replacement) order,
	                                                 // symbol
	                                                 // Side 
                                                         // FIX::TransactTime() );

	// orderCancelRequest.setField(FIX::SecurityType(FIX::SecurityType_FUTURE"));// required for futures and options, tag 167
	// like FIX::SecurityType_FUTURE
	// like FIX::SecurityType_OPTION

	// this needs to be uncommented
	//orderCancelRequest.getHeader().setField(FIX::SenderCompID(_sessionID.getSenderCompID()));
        // orderCancelRequest.getHeader().setField(FIX::TargetCompID(_sessionID.getTargetCompID()));

	
        // FIX::Session::sendToTarget(orderCancelRequest ); // cancel exception thrown ?

	// update db
    }
  }

}

// cancel the GID return the new request
void FIXUtils::processCancelReplace(FIXComp::TradeRequest& request, const std::string& GID)
{
  boost::lock_guard<boost::mutex> lock{_reqMutex};
  {
      // read from db
      boost::lock_guard<boost::mutex> lock{_dbMutex};
      
      // FIX42::OrderCancelReplaceRequest cancelReplaceRequest( queryOrigClOrdID(), ClOrdId to cancel
      //                                                        queryClOrdID(), new ClOrdId
      //                                                        FIX::HandlInst( '1' ), needed but dont care
      //                                                        querySymbol(),
      //                                                        querySide(),
      //                                                        FIX::TransactTime(),
      //                                                        queryOrdType() ); stop, limit, like FIX::OrdType_MARKET 

      // if ( queryConfirm( "New price" ) )
      // cancelReplaceRequest.set( queryPrice() );
      //if ( queryConfirm( "New quantity" ) )
      //cancelReplaceRequest.set( queryOrderQty() );

      // this needs to be uncommented
      // cancelReplaceRequest.getHeader().setField(FIX::SenderCompID(_sessionID.getSenderCompID()));
      // cancelReplaceRequest.getHeader().setField(FIX::TargetCompID(_sessionID.getTargetCompID()));

      //FIX::Session::sendToTarget(cancelReplaceRequest;

      // update db
  }
}

void FIXUtils::processRequests(  FIXComp::TradeRequestList& iRequests, const FIXComp::TradeRequestList& requests)
{
  boost::lock_guard<boost::mutex> lock{_reqMutex};

  int i = requests.size();
  int j = 0;
  for(j = 0 ;j < i; j++)
  {
    iRequests.push_back(requests[j]);
    {
        // store to the db
        boost::lock_guard<boost::mutex> lock{_dbMutex};
    }
    newOrderSingle(iRequests[j]); //  fill out the fix request and GID in request and sends
  }
  
}

void FIXUtils::getRequestsAfterDate(FIXComp::TradeRequestList& _return, const std::string & asOfTime)
{
     boost::lock_guard<boost::mutex> lock{_reqMutex};
    
    {
              boost::lock_guard<boost::mutex> lock{_dbMutex};
    }
}


FIX::ClOrdID FIXUtils::getClOrdId(const std::string& traderId)
{
    char  tmpClOrdId[31];
    std::string tId;
    // mutex acquire
    boost::lock_guard<boost::mutex> lock{_clOrdIDMutex};
    {
      boost::lock_guard<boost::mutex> lock{_dbMutex};
        time_t t = time(NULL);
        tm* timePtr = localtime(&t);
	
	if(_clOrdId >= 100000) // TODO do this in the db
	  _clOrdId = 1;

	if(traderId.size() > TRADERID_SIZE)
	  tId = traderId.substr(0, TRADERID_SIZE);
	else
	  tId = traderId;
	// YYYMMDDtraderIdNNNNNN
        // traderId limit is 16	
	sprintf(tmpClOrdId, "%04d%02d%02d% 16s%06d", timePtr->tm_year + 1900,
		timePtr->tm_mon + 1, timePtr->tm_mday, tId.c_str() , _clOrdId); 
        _clOrdId++;// TODO do this in the db
	BOOST_LOG_TRIVIAL(debug) << " ClOrdId: " << tmpClOrdId;

    }
    return(FIX::ClOrdID(tmpClOrdId));
}

void FIXUtils::logout()
{
  // mutex acquire
  boost::lock_guard<boost::mutex> lock{_reqMutex};

  FIX42::Logout logoutMsg;
  std::string  id;

  id =  _sessionID.getSenderCompID();

  if( id.length() != 0)
  {
    BOOST_LOG_TRIVIAL(debug) << "void FIXUtils::logout() "
                             << " senderCompID: " << _sessionID.getSenderCompID()
			     << " targetCompID: " << _sessionID.getTargetCompID();

    logoutMsg.getHeader().setField(FIX::SenderCompID(_sessionID.getSenderCompID()));
    logoutMsg.getHeader().setField(FIX::TargetCompID(_sessionID.getTargetCompID()));
  }

  FIX::Session::sendToTarget(logoutMsg ); // exception thrown ?
}
