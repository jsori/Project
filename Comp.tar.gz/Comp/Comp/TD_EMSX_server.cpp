#include "gen-cpp/TD_EMSX.h"
#include "TD_EMSX_server.h"

using namespace ::apache::thrift;
using namespace ::apache::thrift::protocol;
using namespace ::apache::thrift::transport;
using namespace ::apache::thrift::server;

using namespace  ::FIXComp;
class Compliance;

TD_EMSXHandler::TD_EMSXHandler(Compliance *comp):_comp(comp)
{
    // Your initialization goes here
}

TD_EMSXHandler::~TD_EMSXHandler()
{
}

void TD_EMSXHandler::RequestTrades(TradeRequestList& _return, const TradeRequestList& tradeReqList)
{
  if(_comp)
  {
    // format to fix, store to dbb and send to db
      _comp->qFixUtils().processRequests(_return, tradeReqList);
  }
}
void TD_EMSXHandler::TradeRequestAfterDateTime(TradeRequestList& _return, const std::string& asOfTime)
{
    _comp->qFixUtils().getRequestsAfterDate(_return, asOfTime);
}

int32_t TD_EMSXHandler::ping()
{
  int32_t i = 1;
    // Your implementation goes here
  printf("ping\n");
  return(i);
}

void TD_EMSXHandler::quit()
{
  std::string p( "TD_EMSXHandler::quit()");
  if(_comp)
    _comp->stop(p);
}
/*
int main(int argc, char **argv) {
  int port = 9090;
  ::apache::thrift::stdcxx::shared_ptr<TD_EMSXHandler> handler(new TD_EMSXHandler());
  ::apache::thrift::stdcxx::shared_ptr<TProcessor> processor(new TD_EMSXProcessor(handler));
  ::apache::thrift::stdcxx::shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));
  ::apache::thrift::stdcxx::shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());
  ::apache::thrift::stdcxx::shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

  TSimpleServer server(processor, serverTransport, transportFactory, protocolFactory);
  server.serve();
  return 0;
}

*/
