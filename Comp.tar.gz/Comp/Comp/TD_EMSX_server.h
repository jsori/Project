#ifndef _TD_EMSX_SERVER_H_
#define _TD_EMSX_SERVER_H_

#include "gen-cpp/TD_EMSX.h"
#include <thrift/protocol/TBinaryProtocol.h>
#include <thrift/server/TSimpleServer.h>
#include <thrift/transport/TServerSocket.h>
#include <thrift/transport/TBufferTransports.h>
#include "Compliance.h"

#include "FIXUtils.h"

using namespace ::apache::thrift;
using namespace ::apache::thrift::protocol;
using namespace ::apache::thrift::transport;
using namespace ::apache::thrift::server;

using namespace  ::FIXComp;
class Compliance;

class TD_EMSXHandler : virtual public TD_EMSXIf {
 public:
  TD_EMSXHandler(Compliance *comp);
  virtual ~TD_EMSXHandler();
  
  void RequestTrades(TradeRequestList& _return, const TradeRequestList& tradeReqList);

  void TradeRequestAfterDateTime(TradeRequestList& _return, const std::string& asOfTime);
  
  int32_t ping();

  void quit();

 private:
  Compliance     *_comp;
};

#endif
/*
int main(int argc, char **argv) {
  int port = 9090;
  ::apache::thrift::stdcxx::shared_ptr<TD_EMSXHandler> handler(new TD_EMSXHandler());
  ::apache::thrift::stdcxx::shared_ptr<TProcessor> processor(new TD_EMSXProcessor(handler));
  ::apache::thrift::stdcxx::shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));
  ::apache::thrift::stdcxx::shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());
  ::apache::thrift::stdcxx::shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

  TSimpleServer server(processor, serverTransport, transportFactory, protocolFactory);
  server.serve();
  return 0;
}

*/
