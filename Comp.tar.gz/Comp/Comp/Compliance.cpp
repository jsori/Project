#include "Compliance.h"
Compliance::Compliance() : _qFix(0), _qFixUtils(0), _svc(0), _svc2(0)
{
}

Compliance::~Compliance()
{
  if(_qFix)
  {
    //     _qFix->stop();
  }

  //should already be stopped
  if(_svc)
  {
    delete _svc;
    _svc = 0;
  }
  //should already be stopped
  if(_svc2)
  {
    delete _svc2;
    _svc2 = 0;
  }
}

// should be 1 service per thread
void Compliance::addSvc( ::apache::thrift::server::TThreadedServer* svc)
{
  _svc = svc;
}
// should be 1 service per thread
void Compliance::addSvc2( ::apache::thrift::server::TThreadedServer* svc)
{
  _svc2 = svc;
}

void Compliance::run(int svcNo)
{
  if(svcNo == 1)
  {
      if(!_qFix)
          BOOST_LOG_TRIVIAL(debug) << "Compliance::run(): NO quickfix";
      else
      {
          _qFix->start(); // do the FIX stuff here
      }
      if(_svc)
      {
         _svc->serve();
      }
      else
        BOOST_LOG_TRIVIAL(debug) << "Compliance::run(): NO _svc";
  }
  else
  {
      if(_svc2)
      {
         _svc2->serve();
      }
      else
        BOOST_LOG_TRIVIAL(debug) << "Compliance::run(): NO _svc2";
  }
}

void Compliance::stop(std::string &from)
{
  BOOST_LOG_TRIVIAL(debug) << "Compliance::stop() from: " << from;
  BOOST_LOG_TRIVIAL(debug) << "Compliance::stop() this: " << this;

  // TODO acquire MUTEX
  // stop the apache thrift
  if(_svc)
  {
      BOOST_LOG_TRIVIAL(debug) << "Compliance::stop(): stopping _svc apache thrift";
    _svc->stop();
    //    delete _svc;
    //_svc = 0;
  }
  else
    BOOST_LOG_TRIVIAL(debug) << "Compliance::stop(): _svc: " << _svc;

  if(_svc2)
  {
    BOOST_LOG_TRIVIAL(debug) << "Compliance::stop(): stopping _svc2 apache thrift";
    _svc2->stop();
    //    delete _svc;
    //_svc = 0;
  }

  // stop the fix connection
  
  if(_qFix)
  {
    //_qFix->stop();
    //delete _qFix;
    //_qFix = 0;
  }
  // TODO release mutex
  BOOST_LOG_TRIVIAL(debug) << "Compliance::stop() from: " << from << " leaving";
}

void Compliance::qFixInitiator(FIX::Initiator *initiator)
{
  _qFix = initiator;
}

void Compliance::qFixUtils(FIXUtils *f)
{
  _qFixUtils = f;
}

FIXUtils &Compliance::qFixUtils()
{
  return(*_qFixUtils);
}

