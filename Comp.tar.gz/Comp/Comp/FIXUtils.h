#ifndef _APPLICATION_H_
#define _APPLICATION_H_

#include "quickfix/Application.h"
#include "quickfix/MessageCracker.h"
#include "quickfix/Values.h"
#include "quickfix/Mutex.h"

#include "quickfix/fix42/IOI.h"
#include "quickfix/fix42/NewOrderSingle.h"
#include "quickfix/fix42/ExecutionReport.h"
#include "quickfix/fix42/OrderCancelRequest.h"
#include "quickfix/fix42/OrderCancelReject.h"
#include "quickfix/fix42/OrderCancelReplaceRequest.h"
#include "quickfix/fix42/Logout.h"

#include <boost/log/trivial.hpp>
#include <boost/thread.hpp>

#include "../gen-cpp/FIXComp_types.h"
#include <queue>

#define TRADERID_SIZE 16

class FIXUtils :
      public FIX::Application,
      public FIX::MessageCracker
{
public:
  void logout();

  void processRequest(FIXComp::TradeRequest& _return, const FIXComp::TradeRequest& request);
  void processFuturesSpreadOrder(FIXComp::TradeRequest& _return, const FIXComp::TradeRequest& request);
  void processBatchOrder(FIXComp::TradeRequest& _return, const FIXComp::TradeRequest& request);
  void processCancelOrder(const std::string& GID);
  void processCancelReplace(FIXComp::TradeRequest& _return, const std::string& GID);

  void processRequests(FIXComp::TradeRequestList& iRequests, const FIXComp::TradeRequestList& requests);
  void getRequestsAfterDate(FIXComp::TradeRequestList& _return, const std::string & asOftime);

private:
  void onCreate( const FIX::SessionID& ) {}
  void onLogon( const FIX::SessionID& sessionID );
  void onLogout( const FIX::SessionID& sessionID );
  void toAdmin( FIX::Message&, const FIX::SessionID& ) {}
  void toApp( FIX::Message&, const FIX::SessionID& )
  throw( FIX::DoNotSend );
  void fromAdmin( const FIX::Message&, const FIX::SessionID& )
  throw( FIX::FieldNotFound, FIX::IncorrectDataFormat, FIX::IncorrectTagValue, FIX::RejectLogon ) {}
  void fromApp( const FIX::Message& message, const FIX::SessionID& sessionID )
  throw( FIX::FieldNotFound, FIX::IncorrectDataFormat, FIX::IncorrectTagValue, FIX::UnsupportedMessageType );

  void onMessage( const FIX42::ExecutionReport&, const FIX::SessionID& );
  void onMessage( const FIX42::OrderCancelReject&, const FIX::SessionID& );

  FIX::ClOrdID getClOrdId(const std::string& traderId);// 31 chars
  
  FIX42::NewOrderSingle newOrderSingle(FIXComp::TradeRequest &request);
  FIX42::OrderCancelReplaceRequest cancelReplaceRequest();

 private:
  boost::mutex _reqMutex;	// requests through quickfix
  boost::mutex _replyMutex;     // replies through quickfix
  boost::mutex _dbMutex;        // dbaccess mutext
  boost::mutex _clOrdIDMutex;   // clOrdID generation mutex
};

#endif
