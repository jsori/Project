//
//

#include "Config.h"


Config::Config() : _desc("Allowed Options")
{
    _desc.add_options()
            ("help,h", "produce help message")
            ("rpcHost,r", po::value<std::string>()->default_value("localhost"), "rpc host: compliance server")
            ("rpcPort,p", po::value<int>()->default_value(DEFAULT_RPC_PORT), "rpc port number")
            ("testRpcPort,t", po::value<int>()->default_value(TEST_RPC_PORT), "test rpc port number")
            ("quickfixCfg,c",  po::value<std::string>()->default_value("../cfg/Comp.cfg"), "quickfix cfg");
}
bool Config::parse(int argc, char* argv[])
{
    bool    result  = true;
    po::store(po::parse_command_line(argc, argv, _desc), _vm);
    po::notify(_vm);

    if (_vm.count("help"))
        result = false;


    return result;
}

// clients use this
std::string Config::rpcHost() const
{
    return _vm["rpcHost"].as<std::string>();
}

int Config::rpcPort() const
{
    int     result = DEFAULT_RPC_PORT;
    if (_vm.count("rpcPort"))
    {
        result = _vm["rpcPort"].as<int>();
    }
    return result;
}

int Config::testRpcPort() const
{
    int     result = TEST_RPC_PORT;
    if (_vm.count("testRpcPort"))
    {
        result = _vm["testRpcPort"].as<int>();
    }
    return result;
}

// quickfix style config file
std::string Config::quickfixCfg() const
{
    return _vm["quickfixCfg"].as<std::string>();
}
